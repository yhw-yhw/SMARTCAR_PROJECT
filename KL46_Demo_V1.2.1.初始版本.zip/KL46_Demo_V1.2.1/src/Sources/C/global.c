#ifndef GLOBAL_C
#define GLOBAL_C 1

#include "global.h"

int16 trueSpeed=0;
int16 g_nSpeedControlCount=1;
int8 have_new_speed=0;
u8 Pixel[128]={0},Pixel_back[128]={0},IntegrationTime=6;
#endif